package com.example.contactlist;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import android.app.AlertDialog;
import android.content.Context;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class BlacklistFragment extends Fragment implements OnClickListener {
	private static final int MENU_UPDATE_ID = 0;
    private static final int MENU_DELETE_ID = 1;
    private Button bt_add_blacknumber;
    private ListView lv_blacknumber;
    private TextView empty;
    private View view;
    private LayoutInflater mInflater;
    private Button bt_ok_blacknumber_dialog;
    private Button bt_cancel_blacknumber_dialog;
    private EditText et_number_blacknumber_dialog;
    private BlackNumberDao blackNumberDao;
    private AlertDialog dialog;
    private ArrayAdapter<String> mAdapter;  
    private int flag = 0;
    private final static int ADD = 1;
    private final static int UPDATE = 2;
    private String blacknumber;
    private List<String> blacknumbers;
 public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState){
	 View rootView=inflater.inflate(R.layout.blacklist_layout,container,false);	  
	 bt_add_blacknumber = (Button) rootView.findViewById(R.id.bt_add_blacknumber);
	 lv_blacknumber = (ListView) rootView.findViewById(R.id.lv_blacknumber);
	 empty = (TextView) rootView.findViewById(R.id.empty);
	 lv_blacknumber.setEmptyView(empty);
	 mInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
     view = mInflater.inflate(R.layout.add_blacknumber_dialog, null);
     et_number_blacknumber_dialog = (EditText) view.findViewById(R.id.et_number_blacknumber_dialog);
     bt_ok_blacknumber_dialog = (Button) view.findViewById(R.id.bt_ok_blacknumber_dialog);
     bt_cancel_blacknumber_dialog = (Button) view.findViewById(R.id.bt_cancel_blacknumber_dialog);
     bt_ok_blacknumber_dialog.setOnClickListener(this);
     bt_cancel_blacknumber_dialog.setOnClickListener(this);
	 blackNumberDao = new BlackNumberDao(getActivity());
	 blacknumbers = blackNumberDao.findAll();
	 mAdapter = new ArrayAdapter<String>(getActivity(),R.layout.blacknumber_item,blacknumbers);
	 lv_blacknumber.setAdapter(mAdapter);
	 bt_add_blacknumber.setOnClickListener(this);

	 registerForContextMenu(lv_blacknumber);
	 return rootView;
}


public void onCreateContextMenu(ContextMenu menu, View v,
    ContextMenuInfo menuInfo) {
// TODO Auto-generated method stub
super.onCreateContextMenu(menu, v, menuInfo);
 
menu.add(0, MENU_UPDATE_ID, 0, "���º���������");
menu.add(0, MENU_DELETE_ID, 0, "ɾ������������");
}

@Override
public boolean onContextItemSelected(MenuItem item) {
// TODO Auto-generated method stub
AdapterContextMenuInfo acmi = (AdapterContextMenuInfo) item.getMenuInfo();
int position = acmi.position;
blacknumber = (String) mAdapter.getItem(position);
int id = item.getItemId();
switch (id) {
case MENU_UPDATE_ID:
    ViewGroup parent = (ViewGroup) view.getParent();
    if(parent != null){
        parent.removeAllViews();
    }
    et_number_blacknumber_dialog.setText(blacknumber);
    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
    builder.setTitle("���º�����");
    builder.setView(view);
    dialog = builder.create();
    dialog.show();
     
    flag = UPDATE;
    break;
case MENU_DELETE_ID:
    blackNumberDao.delete(blacknumber);
    blacknumbers = blackNumberDao.findAll();
	mAdapter = new ArrayAdapter<String>(getActivity(),R.layout.blacknumber_item,blacknumbers);
	lv_blacknumber.setAdapter(mAdapter);
    break;

default:
    break;
}
return super.onContextItemSelected(item);
}

//��ť����¼�
public void onClick(View v) {
// TODO Auto-generated method stub
int id = v.getId();
switch (id) {
case R.id.bt_add_blacknumber:
    ViewGroup parent = (ViewGroup) view.getParent();
    if(parent != null){
        parent.removeAllViews();
    }
    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
    builder.setTitle("���Ӻ�����");
    builder.setView(view);
    dialog = builder.create();
    dialog.show();
    flag = ADD;
    break;
case R.id.bt_ok_blacknumber_dialog:
    String number = et_number_blacknumber_dialog.getText().toString();
    if("".equals(number)){
        Toast.makeText(getActivity(), "���������벻��Ϊ��", 1).show();
    }else{
        boolean isBlackNumber = blackNumberDao.isBlackNumber(number);
        if(isBlackNumber){
            Toast.makeText(getActivity(), "�����Ѿ������ں�������", 1).show();
        }else{
            if(flag == ADD){
                blackNumberDao.add(number);
                Toast.makeText(getActivity(), "�������������ӳɹ�", 1).show();
            }else{
                int _id = blackNumberDao.queryId(blacknumber);
                blackNumberDao.update(_id, number);
                Toast.makeText(getActivity(), "�����������޸ĳɹ�", 1).show();
            }

            dialog.dismiss();
            blacknumbers = blackNumberDao.findAll();
        	mAdapter = new ArrayAdapter<String>(getActivity(),R.layout.blacknumber_item,blacknumbers);
        	lv_blacknumber.setAdapter(mAdapter);
        }
    }
     
    break;
case R.id.bt_cancel_blacknumber_dialog:
    dialog.dismiss();
    break;
default:
    break;
}
}
}