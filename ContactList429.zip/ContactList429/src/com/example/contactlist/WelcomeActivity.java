package com.example.contactlist;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Intent;

public class WelcomeActivity extends Activity {

	private static final long SPLASH_DELAY_MILLIS=2000;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
	new Handler().postDelayed(new Runnable()
	{public void run()
	{   
		goHome();
	}
	},SPLASH_DELAY_MILLIS);
	
	}
	private void goHome(){
		Intent intent=new Intent(WelcomeActivity.this,MainActivity.class);
		WelcomeActivity.this.startActivity(intent);
		WelcomeActivity.this.finish();
	}
				
		
		
	}
    

