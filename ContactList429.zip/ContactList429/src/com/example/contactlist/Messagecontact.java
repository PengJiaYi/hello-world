package com.example.contactlist;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.view.View.OnClickListener;


public class Messagecontact extends Activity {
	private String contastname;
	private String contastphone;
	Button carebutton1,carebutton2,carebutton3,carebutton4;
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.messagecontact);
        carebutton1=(Button)findViewById(R.id.carebutton1);
        carebutton2=(Button)findViewById(R.id.carebutton2);
        carebutton3=(Button)findViewById(R.id.carebutton3);
        carebutton4=(Button)findViewById(R.id.carebutton4);
        Bundle bundle = this.getIntent().getExtras();
         contastname = bundle.getString("name1");
         contastphone = bundle.getString("phone1");
         
         carebutton1.setOnClickListener(new OnClickListener()
         {
        	 @Override
     		public void onClick(View view) {
        		 String mstring = "����ѩ����������ǵô�ɡ��";
        		 String Smsstring = "�װ���"+ contastname + mstring;	 
        		 Uri smsToUri = Uri.parse("smsto:"+contastphone);
     			Intent intent = new Intent(Intent.ACTION_SENDTO, smsToUri);
     			intent.putExtra("sms_body", Smsstring);
     			startActivity(intent);
        	 } 
         });
         carebutton2.setOnClickListener(new OnClickListener()
         {
        	 @Override
     		public void onClick(View view) {
        		 String mstring = "����������ÿ��Ľ��գ������������������ף�����տ��֣�";
        		 String Smsstring = "�װ���"+ contastname + mstring;	 
        		 Uri smsToUri = Uri.parse("smsto:"+contastphone);
     			Intent intent = new Intent(Intent.ACTION_SENDTO, smsToUri);
     			intent.putExtra("sms_body", Smsstring);
     			startActivity(intent);
        	 } 
         });
         carebutton3.setOnClickListener(new OnClickListener()
         {
        	 @Override
     		public void onClick(View view) {
        		 String mstring = "��ÿ��ѽڱ�˼�ף������ϲ��Ľ����Ըף����������顣";
        		 String Smsstring = "�װ���"+ contastname + mstring;	 
        		 Uri smsToUri = Uri.parse("smsto:"+contastphone);
     			Intent intent = new Intent(Intent.ACTION_SENDTO, smsToUri);
     			intent.putExtra("sms_body", Smsstring);
     			startActivity(intent);
        	 } 
         });
         carebutton4.setOnClickListener(new OnClickListener()
         {
        	 @Override
     		public void onClick(View view) {
        		 String mstring = "���þò����ˣ���֪����Ľ�����Σ��Һ������㡣";
        		 String Smsstring = "�װ���"+ contastname + mstring;	 
        		 Uri smsToUri = Uri.parse("smsto:"+contastphone);
     			Intent intent = new Intent(Intent.ACTION_SENDTO, smsToUri);
     			intent.putExtra("sms_body", Smsstring);
     			startActivity(intent);
        	 } 
         });
    }

}
