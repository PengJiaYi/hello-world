package com.example.contactlist;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.ContactsContract;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.CommonDataKinds.StructuredName;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditContact extends Activity {

	String name=null;
	String phone=null;
	String contactId=null;
	String rawId = null;
	
	

	UpdateThread updateThread;
	class UpdateThread extends Thread{
		public Handler mHandler;
		public void run(){
			Looper.prepare();
			mHandler=new Handler(){
				@Override
				public void handleMessage(Message msg){
					if(msg.what==0x123){
						String rawId2=msg.getData().getString("rawId");
						String name2=msg.getData().getString("name");
						String phone2=msg.getData().getString("phone");
						
						ContentValues values=new ContentValues();
						values.put(StructuredName.DISPLAY_NAME, name2);
						getContentResolver().update(ContactsContract.Data.CONTENT_URI,
						    values,
						    Data.RAW_CONTACT_ID + "=? and " + Data.MIMETYPE  + "=?",
						    new String[] { rawId2,StructuredName.CONTENT_ITEM_TYPE });
		                values.clear();
		                
		                values.put(Phone.NUMBER,phone2);
		                if(getContentResolver().update(ContactsContract.Data.CONTENT_URI,
		    				    values,
		    				    Data.RAW_CONTACT_ID + "=? and " + Data.MIMETYPE  + "=?",
		    				    new String[] { rawId2,Phone.CONTENT_ITEM_TYPE})==0){
		                	values.put(Data.RAW_CONTACT_ID,rawId2);
		    				values.put(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE);
		    				getContentResolver().insert(ContactsContract.Data.CONTENT_URI, values);
		                }
		                values.clear();
					}
				}
			};
			Looper.loop();
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_edit_contact);
		
		
		final EditText nameEdit=(EditText)findViewById(R.id.name);
		final EditText phoneEdit=(EditText)findViewById(R.id.phone);
		
		final Button save=(Button)findViewById(R.id.save);
		final Button cancel=(Button)findViewById(R.id.cancel);
		final Button delete=(Button)findViewById(R.id.delete);
		
		final Intent intent =getIntent();
		Bundle bundle=intent.getExtras();
		final String name0=bundle.getString("name");
		final String phone0=bundle.getString("phone");
		
	    updateThread=new UpdateThread();
		updateThread.start();
		
		contactId=bundle.getString("contactId");
	
		Cursor idCursor = getContentResolver().query(
    			ContactsContract.RawContacts.CONTENT_URI, null, null,null, null);  
		idCursor.moveToFirst();
	    while(idCursor.moveToNext()){
        	if(contactId.equals(idCursor.getString(idCursor.getColumnIndex(ContactsContract.RawContacts.CONTACT_ID)))){
       		rawId=idCursor.getString(idCursor.getColumnIndex(ContactsContract.RawContacts._ID));
       		break;
        	}
        }
	    idCursor.close();//��Ӧ��Ϊ��
	    if(rawId.isEmpty()){
	    	finish();
	    }
	    
	    nameEdit.setText(name0);
	    phoneEdit.setText(phone0);

	    save.setEnabled(true);
		nameEdit.addTextChangedListener(new TextWatcher(){  
	       @Override  
	      public void onTextChanged(CharSequence s,int start,int before,int count){  
	        if(nameEdit.length()==0){
	        	save.setEnabled(false);
	        }
	        else{
	        	save.setEnabled(true);
	        }
	      }
	      @Override
	   	  public void beforeTextChanged(CharSequence s, int start, int count,
		 		int after) {
			// TODO Auto-generated method stub
		  }
		  @Override
		  public void afterTextChanged(Editable s) {
			// TODO Auto-generated method stub
		  }  
		});
		
		save.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				name=nameEdit.getText().toString().trim();
				phone=phoneEdit.getText().toString().trim();
		
				//��������  Ҫ�ж��޸ĺ�������Ƿ���������ϵ�˳�ͻ
				boolean exist=false;
				boolean blank=false;
				
				if(name.trim().length()==0){
					blank=true;
				}
				
				if(!name.equals(name0)){
					
					Cursor cursor = getContentResolver().query(
			    			ContactsContract.Contacts.CONTENT_URI,null,null,null,null);
					while(cursor.moveToNext()){
						if(name.equals(cursor.getString(cursor.getColumnIndex(
								ContactsContract.Contacts.DISPLAY_NAME)))){
						      exist=true;
						}
					}
					cursor.close();
				}
				
				if(exist){
					
					Toast.makeText(EditContact.this, "����������ϵ���Ѿ�����", Toast.LENGTH_LONG).show();
					nameEdit.setText(name0);
				}
                if(blank){
					
					Toast.makeText(EditContact.this, "��������Ϊ��", Toast.LENGTH_LONG).show();
					nameEdit.setText(name0);
				}
				
				if((!exist)&&(!blank)){
					
				   
				    Message msg=new Message();
				    msg.what=0x123;
				    Bundle threadBundle=new Bundle();
				    threadBundle.putString("rawId", rawId);
				    threadBundle.putString("name", name);
				    threadBundle.putString("phone", phone);
				    msg.setData(threadBundle);
				    updateThread.mHandler.sendMessage(msg);
					
	              	Intent intent=new Intent(EditContact.this, DetailsActivity.class);
				    Bundle bundle=new Bundle();
					bundle.putString("name", name);
					bundle.putString("phone", phone);
					bundle.putString("contactId", contactId);
					intent.putExtras(bundle);
					startActivity(intent);
					DetailsActivity.instance.finish();
					finish();
					}
				}
		});
		
		
        delete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Dialog dialog=new AlertDialog.Builder(EditContact.this)
				.setMessage("ȷ��ɾ����")
				//�൱�ڵ��ȷ�ϰ�ť
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					 getContentResolver().delete(
					    		ContentUris.withAppendedId(ContactsContract.RawContacts.CONTENT_URI,Integer.parseInt(rawId)),
					    		null, null);
				     Intent intent=new Intent(EditContact.this, MainActivity.class);
				     startActivity(intent);
				}
				})
				//�൱�ڵ��ȡ����ť
				.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				}
				})
				.create();
				dialog.show();
			}
		});
        
        cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				EditContact.this.finish();
			}
		});
	}
}

