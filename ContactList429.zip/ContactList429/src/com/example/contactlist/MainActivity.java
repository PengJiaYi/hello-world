package com.example.contactlist;
import com.example.contactlist.R;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener{
	private ContactsFragment contactsFragment;
	private RecordsFragment recordsFragment;
	private BlacklistFragment blacklistFragment;
	private View contactsLayout;
	private View recordsLayout;
	private View blacklistLayout;
	private ImageView contactsImage;
	private ImageView recordsImage;
	private ImageView blacklistImage;
	private TextView contactsText;
	private TextView recordsText;
	private TextView blacklistText;
	private FragmentManager fragmentManager;
    private static final int AddContact_ID = Menu.FIRST;   
    private static final int EXITContact_ID = Menu.FIRST+1; 
    @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		final Intent intent = new Intent();
		intent.setAction("com.example.contactlist.BlackNumberService");
		startService(intent);
		initViews();
		fragmentManager = getFragmentManager();
		setTabSelection(0);
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu)   
    {  
        super.onCreateOptionsMenu(menu);  
        //������ϵ��  
        menu.add(0, AddContact_ID, 0,"����")   
            .setIcon(R.drawable.ic_launcher);  
        //�˳�����  
        menu.add(0, EXITContact_ID, 1, "�˳�")  
            .setIcon(R.drawable.ic_launcher);  
        return true;  
          
    }  
    public boolean onOptionsItemSelected(MenuItem item)   
    {  
        switch (item.getItemId())   
        {  
        case AddContact_ID:  
        	Intent intent=new Intent(this,AddContact.class);
			startActivity(intent);
            return true;  
        case EXITContact_ID:  
            //�˳�����  
            this.finish();  
            return true;  
        }  
        return super.onOptionsItemSelected(item);  
    }  


	private void initViews() {
		contactsLayout = findViewById(R.id.contacts_layout);
		recordsLayout = findViewById(R.id.records_layout);
		blacklistLayout = findViewById(R.id.blacklist_layout);
		contactsImage = (ImageView) findViewById(R.id.contacts_image);
		recordsImage = (ImageView) findViewById(R.id.records_image);
		blacklistImage = (ImageView) findViewById(R.id.blacklist_image);
		contactsText = (TextView) findViewById(R.id.contacts_text);
		recordsText = (TextView) findViewById(R.id.records_text);
		blacklistText = (TextView) findViewById(R.id.blacklist_text);
		contactsLayout.setOnClickListener(this);
		recordsLayout.setOnClickListener(this);
		blacklistLayout.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.contacts_layout:
			setTabSelection(0);
			break;
		case R.id.records_layout:
			setTabSelection(1);
			break;
		case R.id.blacklist_layout:
			setTabSelection(2);
			break;
		default:
			break;
		}
	}
	private void setTabSelection(int index) {
		clearSelection();
		FragmentTransaction transaction = fragmentManager.beginTransaction();
		hideFragments(transaction);
		switch (index) {
		case 0:
			contactsImage.setImageResource(R.drawable.contacts_selected);
			contactsText.setTextColor(Color.parseColor("#60cd8c"));
			if (contactsFragment == null) {
				contactsFragment = new ContactsFragment();
				transaction.add(R.id.content, contactsFragment);
			} else {
				transaction.show(contactsFragment);
				
			}
			break;
		case 1:
			recordsImage.setImageResource(R.drawable.records_selected);
			recordsText.setTextColor(Color.parseColor("#60cd8c")); //
			if (recordsFragment == null) {
				recordsFragment = new RecordsFragment();
				transaction.add(R.id.content, recordsFragment);
			} else {
				transaction.show(recordsFragment);
			}
			break;
		case 2:
		default:
			blacklistImage.setImageResource(R.drawable.blacklist_selected);
			blacklistText.setTextColor(Color.parseColor("#60cd8c"));
			if (blacklistFragment == null) {
				blacklistFragment = new BlacklistFragment();
				transaction.add(R.id.content, blacklistFragment);
			} else {
				transaction.show(blacklistFragment);
			}
			break;
		}
		transaction.commit();
	}
	private void clearSelection() {
		contactsImage.setImageResource(R.drawable.contacts_unselected);
		contactsText.setTextColor(Color.parseColor("#818589"));
		recordsImage.setImageResource(R.drawable.records_unselected);
		recordsText.setTextColor(Color.parseColor("#818589"));
		blacklistImage.setImageResource(R.drawable.blacklist_unselected);
		blacklistText.setTextColor(Color.parseColor("#818589"));
	}
	private void hideFragments(FragmentTransaction transaction) {
		if (contactsFragment != null) {
			transaction.hide(contactsFragment);
		}
		if (recordsFragment != null) {
			transaction.hide(recordsFragment);
		}
		if (blacklistFragment != null) {
			transaction.hide(blacklistFragment);
		}

	}
	 public void onConfigurationChanged(Configuration newConfig) {
          super.onConfigurationChanged(newConfig);
           if(this.getResources().getConfiguration().orientation ==Configuration.ORIENTATION_LANDSCAPE) {
                // land donothing is ok
           } else if(this.getResources().getConfiguration().orientation ==Configuration.ORIENTATION_PORTRAIT) {
                // port donothing is ok
           }
     } 
}