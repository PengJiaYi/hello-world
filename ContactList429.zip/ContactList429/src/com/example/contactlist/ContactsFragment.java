package com.example.contactlist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import android.app.Fragment;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.ContentObservable;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class ContactsFragment extends Fragment{
	ListView contact_list;
	private ContactListAdapter adapter;
	private List<ContactBean> list;
	private AsyncQueryHandler asyncQueryHandler; // �첽��ѯ���ݿ������
	private QuickAlphabeticBar alphabeticBar; // ����������
	private Map<Integer, ContactBean> contactIdMap = null;
	private EditText search;
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View contactsLayout = inflater.inflate(R.layout.contact_list_view,
				container, false);
		contact_list=(ListView)contactsLayout.findViewById(R.id.contact_list);
	    alphabeticBar = (QuickAlphabeticBar)contactsLayout.findViewById(R.id.fast_scroller);
		asyncQueryHandler = new MyAsyncQueryHandler(getActivity().getContentResolver());
		search=(EditText)contactsLayout.findViewById(R.id.search);
		init();
		
		getActivity().getContentResolver().registerContentObserver(
				ContactsContract.CommonDataKinds.Phone.CONTENT_URI, 
				true, new ContantObserver(new Handler()));
		
		contact_list.setOnItemClickListener(new OnItemClickListener()
		{
		@Override
	     	public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
			TextView nameTV = (TextView) view.findViewById(R.id.name);
			String name=nameTV.getText().toString();
			TextView phoneTV =(TextView) view.findViewById(R.id.number);
			String phone=phoneTV.getText().toString();
	        Intent intent=new Intent(getActivity(),DetailsActivity.class);
			Bundle bundle=new Bundle();
			ContactBean contact = (ContactBean) adapter.getItem(position);
			
			bundle.putString("name", name);
			bundle.putString("phone", phone);
			bundle.putString("contactId", ""+""+contact.getContactId());
			intent.putExtras(bundle);
			startActivity(intent);
		    }
	    });
		
		  
	    search.addTextChangedListener(new TextWatcher(){  
		       @Override  
		      public void onTextChanged(CharSequence s,int start,int before,int count){  
		        String text=search.getText().toString();
		        ListIterator<ContactBean> litr=list.listIterator();
		        List<ContactBean> select=new ArrayList<ContactBean>();
		        while(litr.hasNext()){
		        	ContactBean bean=litr.next();
		        	if(bean.getDesplayName().contains(text)){
		            select.add(bean);
		        	}
		        }
		        
		        ContactListAdapter sAdapter=new ContactListAdapter
		        (getActivity(), select, alphabeticBar);
		        contact_list.setAdapter(sAdapter);
		        
		        if(text.length()==0){
		        	contact_list.setAdapter(adapter);
		        }
		      }

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
			}
	    });

        return contactsLayout;
		}

		/**
		 * ��ʼ�����ݿ��ѯ����
		 */
		private void init() {
			Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI; // ��ϵ��Uri��
			// ��ѯ���ֶ�
			String[] projection = { ContactsContract.CommonDataKinds.Phone._ID,
					ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
					ContactsContract.CommonDataKinds.Phone.NUMBER, "sort_key",
					ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
					ContactsContract.CommonDataKinds.Phone.PHOTO_ID,
					ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY };
			// ����sort_key�����ԃ
			asyncQueryHandler.startQuery(0, null, uri, projection, null, null,
					"sort_key COLLATE LOCALIZED asc");

		}

		/**
		 * 
		 * @author Administrator
		 * 
		 */
		private class ContantObserver extends ContentObserver{
			public ContantObserver(Handler handler){
				super(handler);
			}
			public void onChange(boolean selfChange){
				init();
			}
		}
		
		private class MyAsyncQueryHandler extends AsyncQueryHandler {

			public MyAsyncQueryHandler(ContentResolver cr) {
				super(cr);
			}

			@Override
			protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
				if (cursor != null && cursor.getCount() > 0) {
					contactIdMap = new HashMap<Integer, ContactBean>();
					list = new ArrayList<ContactBean>();
					cursor.moveToFirst(); // �α��ƶ�����һ��
					for (int i = 0; i < cursor.getCount(); i++) {
						cursor.moveToPosition(i);
						String name = cursor.getString(1);
						String number = cursor.getString(2);
						String sortKey = cursor.getString(3);
						int contactId = cursor.getInt(4);
						Long photoId = cursor.getLong(5);
						String lookUpKey = cursor.getString(6);

						if (contactIdMap.containsKey(contactId)) {
							// �޲���
						} else {
							// ������ϵ�˶���
							ContactBean contact = new ContactBean();
							contact.setContactId(contactId);
							contact.setDesplayName(name);
							contact.setPhoneNum(number);
							contact.setSortKey(sortKey);
							contact.setPhotoId(photoId);
							contact.setLookUpKey(lookUpKey);
							list.add(contact);

							contactIdMap.put(contactId, contact);
						}
					}
					if (list.size() > 0) {
						setAdapter(list);
					}
				}

				super.onQueryComplete(token, cookie, cursor);
			}

		}

		private void setAdapter(List<ContactBean> list) {
			adapter = new ContactListAdapter(getActivity(), list, alphabeticBar);
			contact_list.setAdapter(adapter);
			alphabeticBar.init(getActivity());
			alphabeticBar.setListView(contact_list);
			alphabeticBar.setHight(alphabeticBar.getHeight());
			alphabeticBar.setVisibility(View.VISIBLE);
		}
}
	
