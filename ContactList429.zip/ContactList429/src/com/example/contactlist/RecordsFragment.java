package com.example.contactlist;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import android.app.Fragment;
import android.content.AsyncQueryHandler;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CallLog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;


public class RecordsFragment extends Fragment{
	private ListView recordslistview;
	private AsyncQueryHandler asyncQuery;
	private DialAdapter adapter;
	private List<CallLogBean> callLogs;
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View recordsLayout = inflater.inflate(R.layout.records_layout,
				container, false);

		recordslistview = (ListView)recordsLayout.findViewById(R.id.records_listview);
		asyncQuery = new MyAsyncQueryHandler(getActivity().getContentResolver());
		init();
		return recordsLayout;
	}

	private void init() {
		Uri uri = android.provider.CallLog.Calls.CONTENT_URI;
		// ��ѯ����
		String[] projection = { CallLog.Calls.DATE, // ����
				CallLog.Calls.NUMBER, // ����
				CallLog.Calls.TYPE, // ����
				CallLog.Calls.CACHED_NAME, // ����
				CallLog.Calls._ID, // id
		};
		asyncQuery.startQuery(0, null, uri, projection, null, null,
				CallLog.Calls.DEFAULT_SORT_ORDER);
	}

	private class MyAsyncQueryHandler extends AsyncQueryHandler {

		public MyAsyncQueryHandler(ContentResolver cr) {
			super(cr);
		}

		@Override
		protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
			if (cursor != null && cursor.getCount() > 0) {
				callLogs = new ArrayList<CallLogBean>();
				SimpleDateFormat sfd = new SimpleDateFormat("MM-dd hh:mm");
				Date date;
				cursor.moveToFirst(); // �α��ƶ�����һ��
				for (int i = 0; i < cursor.getCount(); i++) {
					cursor.moveToPosition(i);
					date = new Date(cursor.getLong(cursor
							.getColumnIndex(CallLog.Calls.DATE)));
					String number = cursor.getString(cursor
							.getColumnIndex(CallLog.Calls.NUMBER));
					int type = cursor.getInt(cursor
							.getColumnIndex(CallLog.Calls.TYPE));
					String cachedName = cursor.getString(cursor
							.getColumnIndex(CallLog.Calls.CACHED_NAME));// �����������绰���룬������Ĵ���
					int id = cursor.getInt(cursor
							.getColumnIndex(CallLog.Calls._ID));

					CallLogBean callLogBean = new CallLogBean();
					callLogBean.setId(id);
					callLogBean.setNumber(number);
					callLogBean.setName(cachedName);
					if (null == cachedName || "".equals(cachedName)) {
						callLogBean.setName(number);
					}
					callLogBean.setType(type);
					callLogBean.setDate(sfd.format(date));

					callLogs.add(callLogBean);
				}
				if (callLogs.size() > 0) {
					setAdapter(callLogs);
				}
			}
			super.onQueryComplete(token, cookie, cursor);
		}
	}

	private void setAdapter(List<CallLogBean> callLogs) {
		adapter = new DialAdapter(getActivity(), callLogs);
		recordslistview.setAdapter(adapter);
	}
}



