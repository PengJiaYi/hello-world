package com.example.contactlist;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.ContactsContract;
import android.provider.ContactsContract.Data;
import android.provider.ContactsContract.RawContacts;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.CommonDataKinds.StructuredName;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class AddContact extends Activity {
	String name=null;
	String phone=null;
	String email=null;
	String status=null;
	EditText nameEdit,phoneEdit,emailEdit;
	InsertThread insertThread;
	class InsertThread extends Thread{
		public Handler mHandler;
		public void run(){
			Looper.prepare();
			mHandler=new Handler(){
				@Override
				public void handleMessage(Message msg){
					if(msg.what==0x1234){
						String rawId2=msg.getData().getString("rawId");
						String name2=msg.getData().getString("name");
						String phone2=msg.getData().getString("phone");
						
						ContentValues values=new ContentValues();
						
						values.put(Data.RAW_CONTACT_ID,rawId2);
						values.put(Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE);
						values.put(StructuredName.DISPLAY_NAME, name2);
						getContentResolver().insert(ContactsContract.Data.CONTENT_URI, values);
						values.clear();
						
						values.put(Data.RAW_CONTACT_ID,rawId2);
						values.put(Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE);
						values.put(Phone.NUMBER,phone2);
						getContentResolver().insert(ContactsContract.Data.CONTENT_URI, values);
						values.clear();
					}
				}
			};
			Looper.loop();
		}
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_add_contact);
		nameEdit=(EditText)findViewById(R.id.name);
		phoneEdit=(EditText)findViewById(R.id.phone);
		
		final Button save=(Button)findViewById(R.id.save);
		final Button cancel=(Button)findViewById(R.id.cancel);
		
		insertThread=new InsertThread();
		insertThread.start();
		
		save.setEnabled(false);
		nameEdit.addTextChangedListener(new TextWatcher(){  
	       @Override  
	      public void onTextChanged(CharSequence s,int start,int before,int count){  
	        if(nameEdit.getText().toString().trim().length()==0){
	        	save.setEnabled(false);
	        }
	        else{
	        	save.setEnabled(true);
	        }
	      }

	      @Override
	   	  public void beforeTextChanged(CharSequence s, int start, int count,
		 		int after) {
			// TODO Auto-generated method stub
			
		  }

		  @Override
		  public void afterTextChanged(Editable s) {
			// TODO Auto-generated method stub
			
		  }  
		});
	
        save.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				
				name=nameEdit.getText().toString().trim();
				phone=phoneEdit.getText().toString().trim();
				
				boolean exist=false;
				Cursor cursor = getContentResolver().query(
		    			ContactsContract.Contacts.CONTENT_URI,null,null,null,null);
				while(cursor.moveToNext()){
					if(name.equals(cursor.getString(cursor.getColumnIndex(
							ContactsContract.Contacts.DISPLAY_NAME)))){
						exist=true;
						break;
					}
				}
				cursor.close();
				
				if(exist){
					// TODO Auto-generated method stub
					Dialog dialog=new AlertDialog.Builder(AddContact.this)
					.setMessage("����ϵ���Ѿ����ڣ��Ƿ�򿪸���ϵ�����鲢�������α༭��")
					//�൱�ڵ��ȷ�ϰ�ť
					.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Intent intent=new Intent(AddContact.this,DetailsActivity.class);
						
						String contactId2=null;
					    Cursor cursor = getContentResolver().query(
					    			ContactsContract.Contacts.CONTENT_URI, null, null,null, null);  
						    while(cursor.moveToNext()){
					        	if(name.equals(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)))){
					        		contactId2=cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
					       		break;
					        	}
					        }
						    cursor.close();
						    if(contactId2.length()==0){
								finish();
							}
						String phone2=null;
						Cursor phoneCursor=getContentResolver().query(
								ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
								null,
								ContactsContract.CommonDataKinds.Phone.CONTACT_ID+"="+contactId2,null,null);
						while(phoneCursor.moveToNext()){
							phone2=phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
						}
						
						    
					    Bundle bundle=new Bundle();
					    bundle.putString("contactId",contactId2);
						bundle.putString("phone",phone2);
						bundle.putString("name",name);
						
						intent.putExtras(bundle);
						startActivity(intent);
						finish();
					}
					})
					//�൱�ڵ��ȡ����ť
					.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					}
					})
					.create();
					dialog.show();
				}
				
				if(!exist){
					ContentValues values=new ContentValues();
					Uri rawContactUri=getContentResolver().insert(RawContacts.CONTENT_URI,values);
					String rawId=""+ContentUris.parseId(rawContactUri);
					values.clear();
					
					Message msg=new Message();
					msg.what=0x1234;
					Bundle threadBundle=new Bundle();
					threadBundle.putString("rawId", rawId);
					threadBundle.putString("name", name);
					threadBundle.putString("phone", phone);
					msg.setData(threadBundle);
					insertThread.mHandler.sendMessage(msg);
					
				    Intent intent=new Intent(AddContact.this, DetailsActivity.class);
				    
				    String contactId = null;
					Cursor idCursor = getContentResolver().query(
			    			ContactsContract.RawContacts.CONTENT_URI, null, null,null, null);  
					idCursor.moveToFirst();
				    while(idCursor.moveToNext()){
			        	if(rawId.equals(idCursor.getString(idCursor.getColumnIndex(ContactsContract.RawContacts._ID)))){
			        	contactId=idCursor.getString(idCursor.getColumnIndex(ContactsContract.RawContacts.CONTACT_ID));
			       		break;
			        	}
			        }
				    idCursor.close();//��Ӧ��Ϊ��
				    if(contactId.isEmpty()){
				    	finish();
				    }
				    
				    
					Bundle bundle=new Bundle();
					bundle.putString("contactId",contactId);
					bundle.putString("name",name);
					bundle.putString("phone", phone);
					intent.putExtras(bundle);
					startActivity(intent);
					finish();
					}
				}
		});
        
        cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
	        }
        });
	}
	
}
