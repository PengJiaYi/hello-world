package com.example.contactlist;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

//
public class WeatherActivity extends Activity {

	Button btn=null;
	Button back=null;
	String strUrl="http://www.weather.com.cn/data/sk/101280101.html";//
	String strUrlBase="http://weather.com.cn/data/cityinfo/101280101.html";//
	String strUrlSixDay="http://m.weather.com.cn/data/101280101.html";//
//	TextView city=null;
//	TextView temp1=null;
//	TextView temp2=null;
//	TextView weather=null;
	int[] tvs={R.id.city,R.id.temp1,R.id.temp2,R.id.weather};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_main);
		
//		city=(TextView) findViewById(R.id.city);
//		temp1=(TextView) findViewById(R.id.temp1);
//		temp2=(TextView) findViewById(R.id.temp2);
//		weather=(TextView) findViewById(R.id.weather);
		
		btn=(Button)findViewById(R.id.btn);
		back = (Button)findViewById(R.id.ws2_btn_return);
		btn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				new Thread(new GetWeatherInfoRunnable()).start();
			}
		});
		back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				WeatherActivity.this.setResult(RESULT_OK);
				WeatherActivity.this.finish();
			}
		});
		
		
		
	}
	
	Handler handler=new Handler(){
		public void handleMessage(Message msg) {
			String strWeather=msg.getData().getString("strWeather");
			String[] weathers=strWeather.split(",");
			for(int i=0;i<weathers.length;i++){
				String str=weathers[i];
				Log.i("str", str);
				TextView tv=(TextView) findViewById(tvs[i]);
				tv.setText(str);
			}
		};
	};
	
	class GetWeatherInfoRunnable implements Runnable {
		@Override
		public void run() {
			try {
//				JsonReader jr=new JsonReader(new InputStreamReader(is));//
				URL url=new URL(strUrlBase);
				InputStream is=url.openStream();
				String strWeather=parseWeather(is);//��ȡ�����������
				Message msg=new Message();
				Bundle bundle=new Bundle();
				bundle.putString("strWeather", strWeather);
				msg.setData(bundle);
				handler.sendMessage(msg);
				
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		private String parseWeather(InputStream is) {
			String str=Utils.convertStreamToString(is);
			Log.i("str",str);
			
			try {
				JSONObject json=new JSONObject(str);
				JSONObject weatherinfo=json.getJSONObject("weatherinfo");
				String city=weatherinfo.getString("city");
				String temp1=weatherinfo.getString("temp1");
				String temp2=weatherinfo.getString("temp2");
				String weather=weatherinfo.getString("weather");
				Log.i("city",city );
				Log.i("temp1", temp1);
				Log.i("temp2",temp2 );
				Log.i("weather",weather );
				str=city+","+temp1+","+temp2+","+weather;
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return str;
		}
		
	}
}
