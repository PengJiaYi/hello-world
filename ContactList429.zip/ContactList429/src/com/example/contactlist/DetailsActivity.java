package com.example.contactlist;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.QuickContactBadge;
import android.widget.TextView;

public class DetailsActivity extends Activity {
	
	static DetailsActivity instance;
	ImageButton back;
	ImageButton edit;
	ImageButton call;
	ImageButton send;
	TextView nameTV;
	TextView phoneTV;
	QuickContactBadge quickContactBadge;
	
	TextView Weather;
	TextView sendMessage;
	TextView addToBlack;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.details);
		
		instance=this;
	    nameTV=(TextView)findViewById(R.id.name);
		phoneTV=(TextView)findViewById(R.id.phone);
		back=(ImageButton)findViewById(R.id.back);
		edit=(ImageButton)findViewById(R.id.edit);
		call=(ImageButton)findViewById(R.id.call);
		send=(ImageButton)findViewById(R.id.send);
		sendMessage=(TextView)findViewById(R.id.sendMessage);
		Weather = (TextView)findViewById(R.id.weatherActivity);
		
		quickContactBadge = (QuickContactBadge)findViewById(R.id.qcb);
		
		Intent intent=getIntent();
		Bundle bundle=intent.getExtras();
		final String contactId=bundle.getString("contactId");
		final String name=bundle.getString("name");
		final String phone=bundle.getString("phone");
		nameTV.setText(name);
		phoneTV.setText(phone);
		
		if(name.length()==0){
			finish();
		}
		
	    phoneTV.setOnTouchListener(new View.OnTouchListener() {
					@Override
					public boolean onTouch(View v, MotionEvent event) {
						// TODO Auto-generated method stub
						if(phone.length()>0){
							Intent intent=new Intent("android.intent.action.CALL", Uri.parse("tel:"+phone));
							startActivity(intent);
							return false;
						}
						else return false;
					}
		        });
		
	    call.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
			    	Intent intent = new Intent();
					intent.setAction(Intent.ACTION_DIAL);
					String data = "tel:"+phone;
					Uri uri =Uri.parse(data);
					intent.setData(uri);
					startActivity(intent);
			}
		});

	    sendMessage.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(DetailsActivity.this,Messagecontact.class);
				Bundle bundle=new Bundle();
				bundle.putString("name1", name);
				bundle.putString("phone1", phone);
				intent.putExtras(bundle);
			    startActivity(intent); 
			}
		});
	    Weather.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(DetailsActivity.this,WeatherActivity.class);
			    startActivity(intent); 
			}
		});
	    send.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				  Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"+phone));  
			      startActivity(intent); 
			}
		});

        
        back.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
	        }
        });  
		
        edit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(DetailsActivity.this,EditContact.class);
				Bundle bundle=new Bundle();
				bundle.putString("contactId",contactId);
				bundle.putString("name", name);
				bundle.putString("phone", phone);
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});

	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		   if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			   finish();
		       return true;
		   }
		   return super.onKeyDown(keyCode, event);
		}
}
